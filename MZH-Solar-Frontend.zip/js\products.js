/**
 * MZH Solar - Demo Product Dataset
 * Realistic Pakistani Solar & Security Market Products
 * All prices in PKR (Pakistani Rupees)
 */

const MZH_PRODUCTS = [
  // --- SOLAR INVERTERS (Hybrid, On-Grid, Off-Grid) ---
  {
    id: "inv-001",
    name: "Inverex Nitrox 6kW On-Grid / Hybrid Solar Inverter",
    brand: "Inverex",
    sku: "INV-NTX-6K",
    category: "Solar Inverters / UPS",
    subCategory: "Hybrid Solar Inverters",
    price: 365000,
    originalPrice: 395000,
    discountPercent: 8,
    rating: 4.9,
    reviewsCount: 38,
    inStock: true,
    isHotDeal: true,
    isFeatured: true,
    badge: "Bestseller",
    specs: {
      "Rated Power": "6000W / 6kW",
      "System Voltage": "48V DC",
      "MPPT Voltage Range": "120V - 500V DC",
      "Max PV Array Power": "8000W",
      "Grid Type": "Single Phase (Hybrid with Net Metering support)",
      "Warranty": "5 Years Brand Warranty"
    },
    shortSpec: "6kW | 48V | Dual MPPT | IP65 Weatherproof | Smart App",
    description: "The Inverex Nitrox 6kW Hybrid Inverter is engineered for Pakistani conditions, offering seamless net-metering compatibility, dual MPPT tracker, touch LCD screen, and zero transfer time for essential home loads.",
    image: "https://images.unsplash.com/photo-1613665813446-82a78c468a1d?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1545259741-2ea3ebf61fa3?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "inv-002",
    name: "Growatt SPF 5000 ES Off-Grid Solar Inverter",
    brand: "Growatt",
    sku: "GRW-SPF-5000",
    category: "Solar Inverters / UPS",
    subCategory: "Off-Grid Solar Inverters",
    price: 195000,
    originalPrice: 220000,
    discountPercent: 11,
    rating: 4.8,
    reviewsCount: 29,
    inStock: true,
    isHotDeal: true,
    isFeatured: true,
    badge: "Popular Off-Grid",
    specs: {
      "Rated Power": "5000W / 5kVA",
      "System Voltage": "48V DC",
      "MPPT Voltage Range": "120V - 430V DC",
      "Max Solar Input": "6000W",
      "Operation": "Works with or without battery",
      "Warranty": "2 Years"
    },
    shortSpec: "5kW | 48V | Sub-10ms Switching | Works without Battery",
    description: "Growatt SPF 5000 ES is a multi-functional off-grid solar inverter integrated with an MPPT charge controller and pure sine wave inverter. Perfect for homes prone to heavy load shedding.",
    image: "https://images.unsplash.com/photo-1548337138-e87d889cc369?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1584267385494-9fdd9a71ad75?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "inv-003",
    name: "Huawei SUN2000-10KTL-M1 10kW On-Grid 3-Phase Inverter",
    brand: "Huawei",
    sku: "HUA-SUN-10KTL",
    category: "Solar Inverters / UPS",
    subCategory: "On-Grid Solar Inverters",
    price: 490000,
    originalPrice: 530000,
    discountPercent: 7,
    rating: 5.0,
    reviewsCount: 17,
    inStock: true,
    isHotDeal: false,
    isFeatured: true,
    badge: "Tier-1 Commercial",
    specs: {
      "Rated Output": "10kW (10,000W)",
      "Output Voltage": "3-Phase 400V/230V",
      "Max Efficiency": "98.6%",
      "Protection": "AI Powered AFCI Arc Fault Protection",
      "Cooling": "Natural Convection (Fanless & Silent)",
      "Warranty": "10 Years Standard Warranty"
    },
    shortSpec: "10kW 3-Phase | 98.6% Efficiency | AI Arc Fault Detection",
    description: "State-of-the-art commercial & residential 3-phase grid-tied inverter by Huawei. Built-in battery interface allows easy future upgrade to energy storage systems with net metering.",
    image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1581092580497-e0d23cbdf1dc?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "inv-004",
    name: "Fronus Platinum Series 3.2kW Solar Inverter",
    brand: "Fronus",
    sku: "FRO-PLT-3.2K",
    category: "Solar Inverters / UPS",
    subCategory: "Hybrid Solar Inverters",
    price: 142000,
    originalPrice: 160000,
    discountPercent: 11,
    rating: 4.7,
    reviewsCount: 42,
    inStock: true,
    isHotDeal: true,
    isFeatured: false,
    badge: "Budget Friendly",
    specs: {
      "Power": "3200VA / 3000W",
      "Battery Voltage": "24V DC",
      "Solar MPPT Current": "80A",
      "Display": "RGB Color Status LED Bar",
      "Warranty": "1 Year Replacement + 2 Years Service"
    },
    shortSpec: "3.2kW | 24V System | High Voltage MPPT | Anti-Dust Kit",
    description: "Compact, efficient pure sine wave hybrid inverter designed for small to medium households. Operates seamlessly on 24V battery systems with solar blending technology.",
    image: "https://images.unsplash.com/photo-1620714223084-8fcacc6dfd8d?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1581092795360-fd1ca04f0952?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "inv-005",
    name: "Crown Micro Elego 4kW Pure Sine Wave UPS Inverter",
    brand: "Crown Micro",
    sku: "CRN-ELG-4K",
    category: "Solar Inverters / UPS",
    subCategory: "UPS Systems",
    price: 118000,
    originalPrice: 135000,
    discountPercent: 12,
    rating: 4.6,
    reviewsCount: 22,
    inStock: true,
    isHotDeal: false,
    isFeatured: false,
    badge: "Heavy Duty UPS",
    specs: {
      "Output Capacity": "4000VA / 3200W",
      "Battery Voltage": "24V / 48V Options",
      "Waveform": "Pure Sine Wave",
      "Charger": "Selectable 10A/20A/30A Smart Charger",
      "Warranty": "2 Years"
    },
    shortSpec: "4kVA Pure Sine Wave | Fast Transfer | Comprehensive LCD",
    description: "Dependable high-capacity UPS system built for reliable domestic and office backup. Supports computers, refrigerators, fans, and delicate home electronics without buzzing.",
    image: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1581092334651-ddf26d9a09d0?auto=format&fit=crop&w=700&q=80"
  },

  // --- SOLAR PANELS ---
  {
    id: "pan-001",
    name: "Longi Hi-MO 6 Explorer 585W Monofacial Solar Panel",
    brand: "Longi Solar",
    sku: "LNG-HIMO6-585",
    category: "Solar Panels",
    subCategory: "Monocrystalline Panels",
    price: 36500,
    originalPrice: 42000,
    discountPercent: 13,
    rating: 4.9,
    reviewsCount: 64,
    inStock: true,
    isHotDeal: true,
    isFeatured: true,
    badge: "Top Rated Panel",
    specs: {
      "Rated Peak Power": "585 Watts",
      "Cell Type": "HPBC Mono crystalline",
      "Module Efficiency": "22.6%",
      "Frame": "Anodized Aluminum Alloy (Black/Silver)",
      "Connector": "MC4-EVO2 Compatible",
      "Warranty": "12-Year Product + 25-Year Linear Power Warranty"
    },
    shortSpec: "585W HPBC Mono | 22.6% Efficiency | Tier-1 Bloomberg Listed",
    description: "Longi Hi-MO 6 Explorer series features cutting-edge HPBC front busbar-free technology for superior aesthetic appearance and outstanding low-light power generation performance.",
    image: "https://images.unsplash.com/photo-1559302504-64aae6ca6b6d?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "pan-002",
    name: "Jinko Tiger Neo N-Type 580W Bifacial Dual Glass Panel",
    brand: "Jinko Solar",
    sku: "JNK-NEO-580B",
    category: "Solar Panels",
    subCategory: "Bifacial Solar Panels",
    price: 38200,
    originalPrice: 43500,
    discountPercent: 12,
    rating: 4.9,
    reviewsCount: 51,
    inStock: true,
    isHotDeal: true,
    isFeatured: true,
    badge: "N-Type Bifacial",
    specs: {
      "Rated Power": "580 Watts",
      "Bifaciality": "Up to 80% rear-side power gain",
      "Module Efficiency": "22.45%",
      "Technology": "TOPCon N-Type Cells",
      "Temperature Coefficient": "-0.30%/°C (Superior in Hot Weather)",
      "Warranty": "30-Year Performance Warranty"
    },
    shortSpec: "580W TOPCon N-Type | Double Glass | High Heat Resistance",
    description: "Jinko Tiger Neo dual glass bifacial panel captures reflected sunlight from roofs and ground surfaces, generating up to 25% extra energy. Highly recommended for hot Pakistani summers.",
    image: "https://images.unsplash.com/photo-1592833159155-c62df1b65634?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "pan-003",
    name: "Canadian Solar BiHiKu7 660W High Power Bifacial",
    brand: "Canadian Solar",
    sku: "CS-BIHIKU7-660",
    category: "Solar Panels",
    subCategory: "Commercial Solar Panels",
    price: 44500,
    originalPrice: 49000,
    discountPercent: 9,
    rating: 4.8,
    reviewsCount: 19,
    inStock: true,
    isHotDeal: false,
    isFeatured: true,
    badge: "Ultra High Power",
    specs: {
      "Rated Power": "660 Watts",
      "Cell Size": "210mm Large Format Cells",
      "Module Efficiency": "21.2%",
      "Max System Voltage": "1500V DC",
      "Weight": "34.5 kg",
      "Warranty": "12 Years Product, 30 Years Linear Power"
    },
    shortSpec: "660W Super High Output | 210mm Cells | Heavy Commercial Duty",
    description: "Engineered specifically for large commercial rooftops, agricultural tube-wells, and industrial solar projects to minimize mounting structure and balance of system costs.",
    image: "https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1521618755572-156ae0cdd74d?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "pan-004",
    name: "JA Solar DeepBlue 4.0 Pro 550W Mono Panel",
    brand: "JA Solar",
    sku: "JA-DB4-550W",
    category: "Solar Panels",
    subCategory: "Monocrystalline Panels",
    price: 33500,
    originalPrice: 37500,
    discountPercent: 10,
    rating: 4.7,
    reviewsCount: 33,
    inStock: true,
    isHotDeal: false,
    isFeatured: false,
    badge: "Value Pick",
    specs: {
      "Rated Power": "550 Watts",
      "Efficiency": "21.3%",
      "PID Resistance": "Guaranteed Anti-PID",
      "Snow/Wind Load": "5400Pa / 2400Pa certified",
      "Warranty": "12-Year Product Guarantee"
    },
    shortSpec: "550W Half-Cut Mono | Excellent Anti-PID | Verified Tier 1",
    description: "Reliable, high-efficiency half-cut monocrystalline solar panel from JA Solar. Features lower internal resistance and high tolerance to shading.",
    image: "https://images.unsplash.com/photo-1521618755572-156ae0cdd74d?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1559302504-64aae6ca6b6d?auto=format&fit=crop&w=700&q=80"
  },

  // --- SOLAR BATTERIES (Lithium & Deep Cycle) ---
  {
    id: "bat-001",
    name: "Narada 48V 100Ah 4.8kWh LiFePO4 Lithium Iron Battery",
    brand: "Narada",
    sku: "NRD-48100-LFP",
    category: "Solar Batteries",
    subCategory: "Lithium Batteries",
    price: 375000,
    originalPrice: 410000,
    discountPercent: 8,
    rating: 4.9,
    reviewsCount: 44,
    inStock: true,
    isHotDeal: true,
    isFeatured: true,
    badge: "Premium Lithium",
    specs: {
      "Nominal Voltage": "48V / 51.2V DC",
      "Capacity": "100Ah (5.12 kWh nominal)",
      "Chemistry": "Lithium Iron Phosphate (LiFePO4)",
      "Cycle Life": ">6000 Cycles @ 80% DOD",
      "BMS Communication": "CAN / RS485 Compatible with Inverters",
      "Warranty": "5 Years Full Replacement Warranty"
    },
    shortSpec: "5.12kWh LiFePO4 | 6000+ Cycles | Smart CAN/RS485 BMS",
    description: "The gold standard in solar battery storage in Pakistan. Maintenance-free, non-toxic, long-lasting Narada lithium battery pack designed for 10-15+ years of daily deep cycle duty.",
    image: "https://images.unsplash.com/photo-1591488320449-011701bb6704?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "bat-002",
    name: "Pylontech US3000C 48V 3.55kWh Modular Lithium Battery",
    brand: "Pylontech",
    sku: "PYL-US3000C",
    category: "Solar Batteries",
    subCategory: "Lithium Batteries",
    price: 295000,
    originalPrice: 325000,
    discountPercent: 9,
    rating: 4.9,
    reviewsCount: 26,
    inStock: true,
    isHotDeal: false,
    isFeatured: true,
    badge: "Rack Mountable",
    specs: {
      "Nominal Voltage": "48V DC",
      "Capacity": "74Ah (3552Wh)",
      "Depth of Discharge": "95% DOD usable",
      "Expandability": "Stackable up to 16 units in parallel",
      "Design Life": "15+ Years",
      "Warranty": "7 Years Manufacturer Warranty"
    },
    shortSpec: "3.55kWh Modular | 95% Usable DOD | Compatible with All Major Brands",
    description: "Compact 19-inch rack-mounted modular battery. Seamlessly synchronizes with Growatt, Huawei, Victron, and Inverex inverters via CAN communication.",
    image: "https://images.unsplash.com/photo-1580927752452-89d86da3fa0a?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1591488320449-011701bb6704?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "bat-003",
    name: "Phoenix Tubular TX-1800 230Ah Deep Cycle Solar Battery",
    brand: "Phoenix",
    sku: "PHX-TX1800",
    category: "Solar Batteries",
    subCategory: "Deep Cycle Tubular",
    price: 68500,
    originalPrice: 75000,
    discountPercent: 8,
    rating: 4.6,
    reviewsCount: 78,
    inStock: true,
    isHotDeal: true,
    isFeatured: false,
    badge: "Lead-Acid Choice",
    specs: {
      "Voltage": "12V DC",
      "Capacity": "230Ah @ C20",
      "Plate Type": "Heavy Duty Tall Tubular Plates",
      "Electrolyte": "Low Maintenance Lead Acid",
      "Warranty": "1 Year Free Replacement"
    },
    shortSpec: "12V 230Ah Tall Tubular | Heavy Cycle Durability | Acid Indicators Included",
    description: "Pakistan's most trusted tall tubular deep cycle battery. Designed to withstand repetitive power outages and high ambient temperatures with minimum water top-up required.",
    image: "https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1563770660941-20978e870e26?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "bat-004",
    name: "Daewoo DLS-240 Deep Cycle Solar Storage Battery",
    brand: "Daewoo",
    sku: "DAE-DLS-240",
    category: "Solar Batteries",
    subCategory: "Deep Cycle Tubular",
    price: 62000,
    originalPrice: 67000,
    discountPercent: 7,
    rating: 4.5,
    reviewsCount: 37,
    inStock: true,
    isHotDeal: false,
    isFeatured: false,
    badge: "100% Maintenance Free",
    specs: {
      "Voltage": "12V DC",
      "Capacity": "200Ah",
      "Technology": "Enhanced Flooded Tubular",
      "Weight": "55 kg",
      "Warranty": "1 Year Manufacturer Warranty"
    },
    shortSpec: "12V 200Ah | Factory Charged | High Inrush Current Capacity",
    description: "Korean technology manufactured in Pakistan. Ready to use, pre-charged deep cycle battery ideal for 1kVA - 3.2kVA residential solar backup setups.",
    image: "https://images.unsplash.com/photo-1563770660941-20978e870e26?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=700&q=80"
  },

  // --- SOLAR CHARGE CONTROLLERS ---
  {
    id: "scc-001",
    name: "EPEVER Tracer 4210AN 40A MPPT Solar Charge Controller",
    brand: "EPEVER",
    sku: "EPV-TRC-40A",
    category: "Solar Charge Controllers",
    subCategory: "MPPT Charge Controllers",
    price: 32500,
    originalPrice: 37000,
    discountPercent: 12,
    rating: 4.8,
    reviewsCount: 39,
    inStock: true,
    isHotDeal: true,
    isFeatured: true,
    badge: "High Precision MPPT",
    specs: {
      "Rated Current": "40 Amperes",
      "System Voltage": "12V / 24V Auto Detection",
      "Max PV Open Circuit Voltage": "100V DC",
      "Max Input Power": "520W (12V) / 1040W (24V)",
      "Tracking Efficiency": ">=99.5%",
      "Display": "Backlit Multi-function LCD Screen"
    },
    shortSpec: "40A MPPT | 100V PV Input | 99.5% Tracking | Negative Ground",
    description: "High-efficiency MPPT charge controller that extracts up to 30% more power from solar arrays compared to standard PWM controllers. Supports Sealed, Gel, Flooded, and Lithium batteries.",
    image: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1517077304055-6e89abbf09b0?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "scc-002",
    name: "SRNE ML2460 60A 12V/24V MPPT Solar Controller",
    brand: "SRNE",
    sku: "SRN-ML-2460",
    category: "Solar Charge Controllers",
    subCategory: "MPPT Charge Controllers",
    price: 43000,
    originalPrice: 48000,
    discountPercent: 10,
    rating: 4.7,
    reviewsCount: 24,
    inStock: true,
    isHotDeal: false,
    isFeatured: true,
    badge: "Heavy Duty 60A",
    specs: {
      "Rated Charge Current": "60A",
      "Battery Support": "Lithium, AGM, Gel, Lead Acid",
      "Max PV Voltage": "150V DC",
      "Heatsink": "Heavy Die-Cast Aluminum Heat Dissipation",
      "Communication": "RS232 / Bluetooth Module Optional"
    },
    shortSpec: "60A MPPT | 150V Max PV | Dual Period Work Load Control",
    description: "Commercial grade 60 Amp MPPT charge controller suitable for large battery banks and heavy solar panel strings with advanced temperature compensation.",
    image: "https://images.unsplash.com/photo-1517077304055-6e89abbf09b0?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "scc-003",
    name: "Victron Energy SmartSolar MPPT 100/30 (12/24V-30A)",
    brand: "Victron Energy",
    sku: "VIC-SS-10030",
    category: "Solar Charge Controllers",
    subCategory: "MPPT Charge Controllers",
    price: 68000,
    originalPrice: 75000,
    discountPercent: 9,
    rating: 5.0,
    reviewsCount: 15,
    inStock: true,
    isHotDeal: false,
    isFeatured: false,
    badge: "European Quality",
    specs: {
      "Max Charge Current": "30A",
      "Max PV Voltage": "100V",
      "Bluetooth": "Built-in Smart Bluetooth App Telemetry",
      "Efficiency": "98%",
      "Origin": "Netherlands"
    },
    shortSpec: "30A Smart MPPT | Built-in Bluetooth | Ultrafast MPPT Algorithm",
    description: "Premium Dutch-engineered solar charge controller with integrated Bluetooth. Real-time solar yield metrics, battery state of health, and custom charging curves via the VictronConnect app.",
    image: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1581092583537-20d51b4b4f1b?auto=format&fit=crop&w=700&q=80"
  },

  // --- SOLAR ACCESSORIES ---
  {
    id: "acc-001",
    name: "Pure Tinned Copper Solar PV DC Cable 6mm² (100 Meter Roll)",
    brand: "MZH Pro Cables",
    sku: "ACC-CBL-6MM",
    category: "Solar Accessories",
    subCategory: "DC Solar Cables",
    price: 28500,
    originalPrice: 32000,
    discountPercent: 11,
    rating: 4.9,
    reviewsCount: 63,
    inStock: true,
    isHotDeal: true,
    isFeatured: true,
    badge: "TUV Certified",
    specs: {
      "Cross Section": "6mm² (10 AWG)",
      "Conductor": "Tinned Electrolytic Pure Copper Class 5",
      "Insulation": "XLPO Double Layer UV Resistant & Flame Retardant",
      "Voltage Rating": "1500V DC / 1000V AC",
      "Temperature Range": "-40°C to +90°C"
    },
    shortSpec: "6mm² 100m Roll | Double Insulated XLPO | UV & Weatherproof",
    description: "Crucial for preventing fire hazards and power transmission loss. High-grade double insulated tinned copper wire engineered specifically for outdoor solar rooftop arrays.",
    image: "https://images.unsplash.com/photo-1544724569-5f546fd6f2b5?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1526738549149-8e07eca6c147?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "acc-002",
    name: "Suntree DC Circuit Breaker 2P 1000V 32A / 63A",
    brand: "Suntree",
    sku: "ACC-SNT-DCB",
    category: "Solar Accessories",
    subCategory: "Protection Devices",
    price: 3400,
    originalPrice: 4200,
    discountPercent: 19,
    rating: 4.8,
    reviewsCount: 88,
    inStock: true,
    isHotDeal: true,
    isFeatured: false,
    badge: "Essential Safety",
    specs: {
      "Poles": "2-Pole (Positive & Negative Isolation)",
      "Rated Voltage": "1000V DC",
      "Rated Current": "Available in 32A, 40A, 63A",
      "Standard": "IEC 60947-2 Certified"
    },
    shortSpec: "1000V DC 2-Pole | Fast Arc Quenching | DIN Rail Mounted",
    description: "Specialized DC breaker designed to extinguish direct-current electrical arcs instantly. Mandatory safety protection between solar panels and inverters.",
    image: "https://images.unsplash.com/photo-1581092162384-8987c1d64718?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1581092580497-e0d23cbdf1dc?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "acc-003",
    name: "Heavy-Duty Anodized Aluminum L2/L3 Solar Mounting Structure",
    brand: "MZH Structural",
    sku: "ACC-MNT-ALU",
    category: "Solar Accessories",
    subCategory: "Mounting Structures",
    price: 18500,
    originalPrice: 21000,
    discountPercent: 12,
    rating: 4.9,
    reviewsCount: 31,
    inStock: true,
    isHotDeal: false,
    isFeatured: true,
    badge: "Rust-Proof 25Yr",
    specs: {
      "Material": "AL6005-T5 Anodized Aluminum",
      "Fasteners": "SUS304 Stainless Steel Bolts & Spring Nuts",
      "Wind Resistance": "Up to 150 km/h",
      "Tilt Angle": "Adjustable 15° to 30° optimized for Pakistan latitude"
    },
    shortSpec: "Anodized Aluminum | Stainless Hardware | High Wind Certified",
    description: "Premium corrosion-resistant aluminum mounting system. Never rusts, reduces roof load weight, and guarantees optimal tilt angle for maximum solar irradiation.",
    image: "https://images.unsplash.com/photo-1581094794329-c8112a89af12?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1617791160505-6f00504e3519?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "acc-004",
    name: "MC4 Solar Branch Connectors 1000V (5 Pairs with Spanner)",
    brand: "Staubli Compatible",
    sku: "ACC-MC4-5P",
    category: "Solar Accessories",
    subCategory: "Connectors",
    price: 2400,
    originalPrice: 2900,
    discountPercent: 17,
    rating: 4.7,
    reviewsCount: 92,
    inStock: true,
    isHotDeal: true,
    isFeatured: false,
    badge: "IP68 Waterproof",
    specs: {
      "Rating": "1000V DC / 30A",
      "Waterproof Level": "IP68",
      "Contact Material": "Copper Tin Plated",
      "Includes": "5 Male + 5 Female Pins + Assembly Wrenches"
    },
    shortSpec: "IP68 Waterproof | 1000V Rated | Snap-in Lock Mechanism",
    description: "Waterproof, UV-stable plug-and-play connectors with dual seal rings to eliminate loose contact heat and short circuits in solar strings.",
    image: "https://images.unsplash.com/photo-1558346490-a72e53ae2d4f?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1544717302-de2939b7ef71?auto=format&fit=crop&w=700&q=80"
  },

  // --- CCTV & SECURITY PRODUCTS ---
  {
    id: "cctv-001",
    name: "Hikvision 4MP ColorVu Smart Dual-Light Outdoor IP Bullet Camera",
    brand: "Hikvision",
    sku: "HIK-DS-2CD1047",
    category: "CCTV & Security Products",
    subCategory: "IP Cameras",
    price: 18500,
    originalPrice: 22000,
    discountPercent: 16,
    rating: 4.9,
    reviewsCount: 74,
    inStock: true,
    isHotDeal: true,
    isFeatured: true,
    badge: "24/7 Color Night",
    specs: {
      "Resolution": "4 Megapixel (2560 x 1440 @ 25fps)",
      "Night Vision": "Full ColorVu 24/7 with Warm Supplemental LEDs (30m)",
      "Lens": "2.8mm / 4mm Wide Angle F1.0 Super Aperture",
      "Audio": "Built-in Microphone for Real-Time Audio Recording",
      "Protection": "IP67 Water & Dust Resistant",
      "Power": "PoE (Power over Ethernet) or 12V DC"
    },
    shortSpec: "4MP 2K | 24/7 Vivid Color in Pitch Darkness | Built-in Mic | IP67",
    description: "Hikvision ColorVu technology provides 24/7 vivid colorful images even in complete darkness. Features intelligent human and vehicle target classification to eliminate false alarms.",
    image: "https://images.unsplash.com/photo-1557597774-9d273605dfa9?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1580894732444-8ecded7900cd?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "cctv-002",
    name: "Dahua 5MP Full-Color WizSense Dome IP Security Camera",
    brand: "Dahua",
    sku: "DAH-IPC-HDW2541",
    category: "CCTV & Security Products",
    subCategory: "IP Cameras",
    price: 19800,
    originalPrice: 23500,
    discountPercent: 16,
    rating: 4.8,
    reviewsCount: 46,
    inStock: true,
    isHotDeal: false,
    isFeatured: true,
    badge: "AI WizSense",
    specs: {
      "Resolution": "5 Megapixel Ultra HD",
      "Smart Detection": "Perimeter Protection, Tripwire, Intrusion Detection",
      "Compression": "Smart H.265+ (Saves 70% storage and bandwidth)",
      "Night Vision": "Dual Smart Warm Light & IR up to 30 meters",
      "Body": "Metal Casing Vandal-Resistant Eyeball"
    },
    shortSpec: "5MP UHD | AI Perimeter Detection | Built-in Mic | Metal Housing",
    description: "Advanced WizSense AI algorithms filter out trees, rain, and pets to alert you only when humans or cars enter your premises. Ideal for homes, solar stations, and warehouses.",
    image: "https://images.unsplash.com/photo-1580894732444-8ecded7900cd?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1557597774-9d273605dfa9?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "cctv-003",
    name: "Hikvision 8-Channel 4K AcuSense PoE NVR Network Video Recorder",
    brand: "Hikvision",
    sku: "HIK-NVR-7608NI",
    category: "CCTV & Security Products",
    subCategory: "DVR / NVR",
    price: 52000,
    originalPrice: 59000,
    discountPercent: 12,
    rating: 4.9,
    reviewsCount: 32,
    inStock: true,
    isHotDeal: true,
    isFeatured: true,
    badge: "4K AcuSense",
    specs: {
      "Channels": "8 Independent PoE Network Ports (Plug & Play)",
      "Decoding Capacity": "Up to 8-ch @ 1080p / 2-ch @ 4K 8MP",
      "Storage": "Supports 2x SATA HDDs up to 10TB each (20TB total)",
      "Output": "4K HDMI + 1080p VGA Simultaneous Output",
      "Remote Access": "Hik-Connect Mobile App (Zero Port Forwarding Needed)"
    },
    shortSpec: "8-Ch PoE Plug & Play | 4K Ultra HD | AI Human/Vehicle Search",
    description: "Standalone high-performance 4K NVR with built-in Power over Ethernet ports. Power your cameras and stream high definition video over a single network cable with smart mobile notifications.",
    image: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "cctv-004",
    name: "Imou Ranger 2 4MP 360° Smart Wi-Fi Indoor Security Camera",
    brand: "Imou (Dahua)",
    sku: "IMU-RANG2-4M",
    category: "CCTV & Security Products",
    subCategory: "Wi-Fi Cameras",
    price: 9800,
    originalPrice: 12500,
    discountPercent: 21,
    rating: 4.7,
    reviewsCount: 110,
    inStock: true,
    isHotDeal: true,
    isFeatured: false,
    badge: "Best Wi-Fi Cam",
    specs: {
      "Resolution": "4 Megapixel Quad HD",
      "Pan & Tilt": "0~355° Pan & -5~80° Tilt (Full 360° Coverage)",
      "Smart Tracking": "Auto-tracks moving human targets",
      "Two-Way Audio": "Built-in Speaker and High-Gain Mic",
      "Privacy Mode": "Physical lens tuck to protect family privacy",
      "Storage": "MicroSD Card Slot (up to 256GB) + Cloud Storage Option"
    },
    shortSpec: "4MP QHD | 360° Pan/Tilt | Human Motion Tracking | Two-Way Talk",
    description: "Easy do-it-yourself indoor surveillance. Connects directly to home Wi-Fi in 2 minutes via mobile phone. Features baby crying detection and instant siren deterrence.",
    image: "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1557597774-9d273605dfa9?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "cctv-005",
    name: "Western Digital Purple 4TB Surveillance Grade Hard Drive",
    brand: "Western Digital",
    sku: "CCTV-WD-PUR4TB",
    category: "CCTV & Security Products",
    subCategory: "CCTV Accessories",
    price: 36000,
    originalPrice: 39500,
    discountPercent: 9,
    rating: 4.9,
    reviewsCount: 57,
    inStock: true,
    isHotDeal: false,
    isFeatured: false,
    badge: "24/7 Continuous",
    specs: {
      "Capacity": "4 Terabytes (4000GB)",
      "Workload Rate": "180 TB/year (3x higher than standard desktop drives)",
      "AllFrame Technology": "Reduces frame loss and pixelation in HD video",
      "Cameras Supported": "Up to 64 HD video surveillance cameras",
      "Warranty": "3 Years Official Warranty"
    },
    shortSpec: "4TB Surveillance Drive | AllFrame Tech | Engineered for 24/7 DVR/NVR",
    description: "Specially tuned for continuous 24/7 video surveillance systems with high thermal operating limits and reduced frame drop technology.",
    image: "https://images.unsplash.com/photo-1597872200969-2b65d56bd16b?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "cctv-006",
    name: "Pure Copper RG59 Coaxial Cable with 2-Core DC Power (100M)",
    brand: "MZH Security Cables",
    sku: "CCTV-CBL-RG59",
    category: "CCTV & Security Products",
    subCategory: "CCTV Accessories",
    price: 13500,
    originalPrice: 15500,
    discountPercent: 13,
    rating: 4.6,
    reviewsCount: 41,
    inStock: true,
    isHotDeal: false,
    isFeatured: false,
    badge: "Solid Copper",
    specs: {
      "Type": "RG59 Coax + 2x0.75mm² DC Power Siamese Cable",
      "Shielding": "95% Tinned Bare Copper Braiding",
      "Jacket": "Flame Retardant PVC",
      "Length": "100 Meters Roll"
    },
    shortSpec: "100m Siamese Roll | Pure Copper Conductor | Video + Power in 1",
    description: "Professional siamese cable allows installers to route both CCTV video signal and 12V camera power in a single clean run.",
    image: "https://images.unsplash.com/photo-1544724569-5f546fd6f2b5?auto=format&fit=crop&w=700&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1544717302-de2939b7ef71?auto=format&fit=crop&w=700&q=80"
  }
];

// Pre-defined Solar System Packages
const MZH_PACKAGES = [
  {
    id: "pkg-01",
    title: "Essential Home Solar",
    badge: "Most Popular for 5-10 Marla Homes",
    capacityPlaceholder: "3.2 kW System",
    pricePlaceholder: "Starting from PKR 580,000",
    inverterCapacity: "3.2kW Pure Sine Wave Hybrid Inverter",
    panelCapacity: "6x 585W Tier-1 Mono Solar Panels (3,510W Total)",
    batteryCapacity: "2x 230Ah Heavy Duty Tubular Batteries",
    idealFor: "Running 4-6 Fans, 10-15 LED Lights, 1 Inverter Refrigerator, 1 TV, Laptop & Mobile Charging",
    features: [
      "Tier-1 Bloomberg Approved 585W Monofacial Panels",
      "3.2kW Hybrid Inverter with Net-Metering Feasibility",
      "Custom G.I / Aluminum Rooftop Structure",
      "Complete DC/AC Breakers & Lightning Surge Protection",
      "Pure Copper 6mm² TUV Certified DC Wiring",
      "Professional On-Site Installation & Load Balancing",
      "1 Year Comprehensive Workmanship Support"
    ],
    recommended: false
  },
  {
    id: "pkg-02",
    title: "Complete Home Solar",
    badge: "Recommended for 1-Kanal Houses",
    capacityPlaceholder: "6 kW Hybrid System",
    pricePlaceholder: "Starting from PKR 1,150,000",
    inverterCapacity: "6kW Nitrox / Growatt Dual MPPT Hybrid Inverter",
    panelCapacity: "11x 585W Tier-1 Mono Panels (6,435W Total)",
    batteryCapacity: "1x 5.12kWh 100Ah LiFePO4 Lithium Iron Battery",
    idealFor: "1.5 Ton Inverter AC in daytime, 1 Refrigerator, 1 Deep Freezer, Water Pump 1HP, Fans, Lights & CCTV",
    features: [
      "Runs Inverter AC directly on solar energy",
      "Zero switchover delay (UPS grade for sensitive electronics)",
      "High-efficiency 5.12kWh Lithium battery (6000+ cycle life)",
      "Net-Metering preparation with Bi-Directional Green Meter filing",
      "Mobile App remote monitoring via Wi-Fi/Cloud",
      "Earthing bore with Copper Chemical Electrode",
      "5-Year Inverter Warranty & 25-Year Panel Power Guarantee"
    ],
    recommended: true
  },
  {
    id: "pkg-03",
    title: "Commercial Solar Solutions",
    badge: "Shops, Plazas & Light Industrial",
    capacityPlaceholder: "10 kW - 20 kW On-Grid",
    pricePlaceholder: "Starting from PKR 1,650,000",
    inverterCapacity: "10kW / 15kW 3-Phase Huawei / Growatt Inverter",
    panelCapacity: "18-36x 580W N-Type Bifacial Panels",
    batteryCapacity: "Optional High-Voltage Lithium Bank",
    idealFor: "Offices, Clinics, Schools, Petrol Pumps, Commercial Shops & Rooftops with heavy daytime peak load",
    features: [
      "Three-Phase On-Grid with Reverse Power Protection",
      "Maximum Net Metering generation to export surplus units",
      "High yield N-Type TOPCon bifacial modules",
      "Walkway and safety rails on industrial roofs",
      "Detailed DISCO (LESCO/IESCO/KE) Net-Metering consultancy",
      "Engineering procurement and turnkey commissioning",
      "Full post-installation performance audits"
    ],
    recommended: false
  },
  {
    id: "pkg-04",
    title: "Customized Solar Installation",
    badge: "Tailored to Your Exact Load",
    capacityPlaceholder: "Custom Sized (1kW - 100kW+)",
    pricePlaceholder: "Custom Quotation",
    inverterCapacity: "Single or Three Phase according to sanctioned load",
    panelCapacity: "Designed based on available shade-free roof area",
    batteryCapacity: "Off-Grid, Hybrid, or Grid-Tied without battery",
    idealFor: "Farmhouses, Tube-wells, Textile mills, Remote locations or specific high-power industrial machinery",
    features: [
      "Detailed on-site solar irradiance & shade assessment",
      "Harmonic load analysis and phase balancing",
      "Flexible financing & installment guidance",
      "High-voltage solar water pumping solutions",
      "CCTV and perimeter security integration package",
      "Tier-1 components sourced directly from official importers",
      "Dedicated account manager & 24/7 technical helpdesk"
    ],
    recommended: false
  }
];

// Helper functions for easy querying
function getAllProducts() {
  return [...MZH_PRODUCTS];
}

function getProductById(id) {
  return MZH_PRODUCTS.find(p => p.id === id) || null;
}

function getProductsByCategory(categoryName) {
  if (!categoryName || categoryName === "All") return MZH_PRODUCTS;
  return MZH_PRODUCTS.filter(p => 
    p.category.toLowerCase().includes(categoryName.toLowerCase()) ||
    (p.subCategory && p.subCategory.toLowerCase().includes(categoryName.toLowerCase()))
  );
}

function getHotDeals() {
  return MZH_PRODUCTS.filter(p => p.isHotDeal);
}

function getFeaturedProducts() {
  return MZH_PRODUCTS.filter(p => p.isFeatured);
}

function formatPKR(amount) {
  return "PKR " + Number(amount).toLocaleString('en-PK');
}
